"""
Simren Kaur
Class: CS 521 - Summer 2
08/03/2021
Homework Problem 5.8.4

"""
import re


def list_to_once_words(x):
    '''
    takes a list as an argument
    returns a list that contains only words that occurred TWICE in the file
    '''
    lst = []
    for i in x:
        if x.count(i) == 2:
            if i not in lst:
                lst.append(i)
    return lst

# use words.txt
file = input("Enter a file: ")
file_content = (open(file, "r")).read().replace('\n', '')
without_punct = re.sub(r'[^\w\s]', "", file_content)
x = re.split("\s", without_punct)

print(list_to_once_words(x))
