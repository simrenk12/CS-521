"""
Simren Kaur
Class: CS 521 - Summer 2
08/03/2021
Homework Problem 5.6.2



"""

def letter_counts(STRING):
    '''
    - takes a string as its argument
    - returns a dictionary of letters as keys and frequency counts as values
    '''

    d = {}
    for i in STRING:
        if i in d:
            d[i] += 1
        else:
            d[i] = 1
    return d


def most_common_letter(STRING):
    '''
    -takes a string as its argument
    - returns a string of the most common letter
    '''

    d = letter_counts(STRING)
    most_frequent = max(d.values())
    maximum = max(d, key=d.get)
    return maximum,most_frequent


def string_count_histogram(STRING):
    '''this function ...'''

    d = letter_counts(STRING)
    for key in sorted(d):
        print(key * d[key])


if __name__ == '__main__':

    STRING = "WAS IT A RAT I SAW"
    STRING = STRING.replace(" ", "")
    print("1. Letter counts:", str(letter_counts(STRING))[1:-1])
    print('2. Most frequent letter is : "', most_common_letter(STRING)[0], '" appears', most_common_letter(STRING)[1],
          'times.')
    string_count_histogram(STRING)