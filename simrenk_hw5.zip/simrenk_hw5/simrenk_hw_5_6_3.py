"""
Simren Kaur
Class: CS 521 - Summer 2
08/03/2021
Homework Problem 5.6.3

Multiply the first number by the second number, then add that result to the
third number, and finally, divide the result by the fourth number.

This program MUST NOT CRASH.

"""
while True:
    try:
        num1, num2, num3, num4 = input("enter 4 numbers with a space between each number: ").split()
        num1, num2, num3, num4 = int(num1), int(num2), int(num3), int(num4)
        result = (num1*num2*num3)/num4
        print(result)
        break
    except ValueError:
        print("Error: you have entered the wrong value")

    except ZeroDivisionError:
        if num4 == 0:
            print("Error: you can not divide by zero")