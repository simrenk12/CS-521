"""
Simren Kaur
Class: CS 521 - Summer 2
08/03/2021
Homework Problem 5.15.5

"""

def factorial(number):
    '''
    - takes the starting integer as its argument
    - calculated the factorial using recursion
    - returns the value
    '''
    if (number == 1 or number == 0):
        return 1
    else:
        return (number * factorial(number - 1))

def factorial2(number):
    '''
    - takes the starting integer as its argument
    - calculated the factorial using without recursion
    - returns the value
    '''

    if (number == 1 or number == 0):
        return 1
    else:
        fact = 1
        while (number > 1):
            fact *= number
            number -= 1
        return fact

while True:
    try:
        number = int(input("Enter a factorial starting integer: "))
        break
    except ValueError:
        print("Error: you have entered the wrong value")

print("The factorial number is",factorial(number),"using recursion")
print("The factorial number is",factorial2(number),"not using recursion")