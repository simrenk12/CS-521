"""
Simren Kaur
Class: CS 521 - Summer 2
08/03/2021
Homework Problem 5.5.1


- Continually prompts user for a text file to read until a valid file is supplied
- Create a function named vc_counter()
- Call vc_counter() and print the total vowels and consonants with appropriate descriptions.

"""

def vc_counter(file_content):

    '''
    - takes the valid file name as an argument
    - counts the number of vowels and consonants in the file
    - returns a dictionary of the count values
    '''

    vowels = "AEIOUaeiou"
    consonants = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ"
    vowel_count = {'vowels': 0}
    consonant_count = {'consonants': 0}

    for i in file_content.read():
        if i in vowels:
            vowel_count['vowels'] += 1
        elif i in consonants:
            consonant_count['consonants'] += 1

    v_values = str(sorted(vowel_count.values()))[1:-1]
    c_values = str(sorted(consonant_count.values()))[1:-1]

    print("Number of vowels:", v_values)
    print("Number of consonants:", c_values)

# use file.txt
file = input("Enter a file: ")
file_content = open(file, "r")
vc_counter(file_content)


file_content.close()
