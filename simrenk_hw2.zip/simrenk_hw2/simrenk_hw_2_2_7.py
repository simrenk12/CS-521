"""
Simren Kaur
Class: CS 521 - Summer 2
07/15/2021
Homework Problem 2.1.7

Rewrite this following ‘for loop’ as a ‘while loop’ and create a working program

X = 10
for i in range(1, X + 1):
    if X % i == 0: print(i)

"""

X = 10
i = 1

while i < (X + 1):
    if X % i == 0:
        print(i)
    i += 1
