"""
Simren Kaur
Class: CS 521 - Summer 2
07/15/2021
Homework Problem 2.1.6

Using a ‘for loop’ , write a program that calculated and prints all the leap years from 1899 to 2021. Then perform this
calculation a second time using a ‘while loop’. For each looping method, print all the year results on one comma
separated line.

"""


# For loop program that calculated and prints all the leap years from 1899 to 2021
def forLeapYear():
    years = list(range(1899, 2021))
    leapYears = []
    count = 0
    for year in years:
        if year % 4 == 0:
            leapYears.insert(count, year)
            count += 1
    print(leapYears)


# While loop program that calculated and prints all the leap years from 1899 to 2021
def whileLeapYear():
    start = int(1899)
    end = int(2021)
    leapYears = []
    count = 0
    while start < end:
        if start % 4 == 0:
            leapYears.insert(count, start)
            count += 1
        start += 1
    print(leapYears)


# Calling the functions
forLeapYear()
whileLeapYear()
