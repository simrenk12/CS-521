"""
Simren Kaur
Class: CS 521 - Summer 2
07/15/2021
Homework Problem 2.1.5

Body Mass Index (BMI) is a number calculated from a person’s weight and height.
The metric formula for BMI is:weight / height**2 where weight is in kilograms and height is in meters.

"""

# clearly prompts user for weight and height in one input
w = float(input("Enter your weight in kilograms: "))
h = float(input("Enter your height in meters: "))
# performs BMI calculation
bmi = w / h ** 2
# prints BMI calculation with an appropriate description
print("Body Max Index (BMI) for Weight", w,"and Height", h, ":", round(bmi, 2))
