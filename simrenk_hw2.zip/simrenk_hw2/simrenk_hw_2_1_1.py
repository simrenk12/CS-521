"""
Simren Kaur
Class: CS 521 - Summer 2
07/15/2021
Homework Problem 2.1.1

Write a Python program that prompts the user to enter a number. In one calculation, take that number, add 2, multiply
by 3, subtract 6, and divide by 3. Use an IF statement to check whether the input matches the calculated value and print
the result of this check-in a descriptive message.

"""

# prompts the user to enter a number
number = int(input("Enter a number: "))
# In one calculation, take that number, add 2, multiply by 3, subtract 6, and divide by 3.
new_number = int((((number + 2) * 3) - 6) / 3)

# Use an IF statement to check whether the input matches the calculated value
if number == new_number:
    print(new_number, " is equal to ", number)
else:
    # print the result of this check in a descriptive message.
    print(new_number, " is not equal to ", number)