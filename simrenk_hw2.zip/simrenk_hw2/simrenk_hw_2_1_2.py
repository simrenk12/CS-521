"""
Simren Kaur
Class: CS 521 - Summer 2
07/15/2021
Homework Problem 2.1.2

Prompt user for input and then print that input as a string, an integer, and a floating‐point value.What data types can
be input that will print without generating any errors? Answer this question at the end of your code by using a
docscring comment.

"""

# Prompt user for input
x = input("Enter an input: ")
# Print that input as a string, an integer, and a floating‐point value.
print(str(x))

print(int(x))

print(float(x))

# What data types can be input that will print without generating any errors?
# Answer this question at the end of your code by using a docscring comment.
"""
When ran the program I tested it using an integer, a float, and a string. When I enter an integer the program does not
run into any error and prints out the input as a string, an integer, and a float value. When I enter a string into the
input I get the error that says "invalid literal for int() with base 10". When I entered afloat as an input I got the
same error that I got when I entered a string as an input. Therefore, the only data type that can be input that will
print without generating any errors is an integer.
"""