"""
Simren Kaur
Class: CS 521 - Summer 2
07/15/2021
Homework Problem 2.1.3

Write a Python program that asks the user to enter an integer (n) and computes the value of n+n*n+n*n*n+n*n*n*n = ?.
The program must then print the formula, replacing the ‘n’ variables with the user input, and the ? with the calculation
results. Numbers greater than 1,000 must have a comma separator. Print using a formatted string or the format function.

"""

# asks the user to enter an integer (n)
n = int(input("Enter an integer: "))

# computes the value of n+n*n+n*n*n+n*n*n*n = ?
x = n + n * n + n * n * n + n * n * n * n

# Numbers greater than 1,000 must have a comma separator
if x > 1000:
    # Print using a formatted string or the format function.
    print(F"{x:,}")  # need to have the , in the number
else:
    # Print using a formatted string or the format function.
    print(x)
