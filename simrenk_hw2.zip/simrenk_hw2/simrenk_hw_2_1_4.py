"""
Simren Kaur
Class: CS 521 - Summer 2
07/15/2021
Homework Problem 2.1.4

One way to determine whether an integer is even or odd is to divide the number by two and check the remainder.
Write a three‐line program that (1) prompts for a number, (2) converts the input to an integer and (3) prints the number
0 if the user input is even and the number 1 if the user input is odd.

"""

# prompts for a number
# converts the input to an integer
number = int(input("Enter an integer: "))
#  prints the number 0 if the user input is even
if number % 2 == 0: print(0)
# and the number 1 if the user input is odd
else: print(1)
