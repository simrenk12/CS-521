"""
Simren Kaur
Class: CS 521 - Summer 2
07/20/2021
Homework Problem 3.14.16

Write a program to read the file line by line and store all the records in
lists or tuples.

"""
# Read the file
try:
    f = open('records.txt', 'r')
except FileNotFoundError:
    print('File does not Exist')
    quit()

# Initialize our list
data = []

for line in f:
    data.append(
        line.strip().split(', '))  # Adding each line to our list of list

# Print the list of lists
print(data)

# Closing the file
f.close()
