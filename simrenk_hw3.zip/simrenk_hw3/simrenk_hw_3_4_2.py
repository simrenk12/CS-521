"""
Simren Kaur
Class: CS 521 - Summer 2
07/20/2021
Homework Problem 3.4.2

- Print the entire string and its length.
- Print the middle character.
- Print the string up to but not including the middle character.
- Print the string from immediately following the middle character to the end.

"""
STRING = "A man a plan a canal Panama"
if len(STRING)%2 == 1:
    # Print the entire string and its length.
    print(f'My {len(STRING)}-character string is: "', STRING, '"')

    middle_char = STRING[(len(STRING) - 1) // 2:(len(STRING) + 2) // 2]
    # Print the middle characte
    print(f'The middle character is: "', middle_char, '"')
    middle_index = int(len(STRING) / 2)
    # Print the string up to but not including the middle character
    print(f'The 1st half of string is:"' + STRING[:middle_index] + '"')
    #Print the string from immediately following the middle character to the end
    print(f'The 1st half of string is:"' + STRING[middle_index+1:] + '"')
else:
    print("String is not odd length")
