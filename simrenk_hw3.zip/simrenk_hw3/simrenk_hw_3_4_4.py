"""
Simren Kaur
Class: CS 521 - Summer 2
07/20/2021
Homework Problem 3.4.4

Write a program that prompts the user to enter a three‐digit whole number
such that the digits are in ascending order and without duplicates.

"""

while True:
    number = input('Please enter a 3-digit integer: ')

    if not number.isnumeric():
        print('Error: This is not an integer. Please re-enter.')

    elif len(number) != 3:
        print('Error: You did not enter a 3-digit number.')

    elif len(set(str(int(number)))) < len(str(int(number))):
        print('Your number contains duplication.')

    elif number != ''.join(sorted(number)):
        print('Error: The digits are not in ascending order.')

    else:
        number = int(number)
        print('Number Accepted!')
        break
