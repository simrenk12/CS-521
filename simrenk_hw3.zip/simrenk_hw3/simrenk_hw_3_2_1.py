"""
Simren Kaur
Class: CS 521 - Summer 2
07/20/2021
Homework Problem 3.2.1

Write a Python program that counts the number of odd numbers, even numbers,
squares of an integer and cubes of an integer from 2 to 130 (inclusive).
For example, 9 is both odd and a square, 8 is even and a cube.Use constants to
set the beginning and ending of the range.

"""

# find the amount of evens
def EvenCount(START, END):
    even = 0
    for number in range(START, END + 1, 2):
        even += 1
    evenFirst = (range(2, 130 + 1, 2)[0])
    evenLast = ((range(2, 130 + 1, 2)[-1]))
    print("Even (", even, "): ", evenFirst, "...", evenLast)

# find the amount of odds
def OddCount(START, END):
    odd = 0
    for number in range(START, END + 1):
        if number % 2 == 1:
            odd += 1
    oddFirst = (range(2, 130 + 1)[1])
    oddLast = (range(2, 130 + 1)[-2])
    print("Odd (", odd, "): ", oddFirst, "...", oddLast)

# find the amount of square #s
def SquareCount(START, END):
    square = 0
    x = 1
    value = []
    for number in range(START, END + 1):
        while x * x <= number:
            if x * x == number:
                value.append(number)
                square = square + 1
            x = x + 1
        number = number + 1
    print("Square (", square, "): ", value)

# find the amount of cube #s
def CubeCount(START, END):
    cube = 0
    x = 1
    value = []
    for number in range(START, END + 1):
        while x * x * x <= number:
            if x * x * x == number:
                value.append(number)
                cube = cube + 1
            x = x + 1
        number = number + 1
    print("Cube (", cube, "): ", value)


START = 2
END = 130
EvenCount(START, END)
OddCount(START, END)
SquareCount(START, END)
CubeCount(START, END)
