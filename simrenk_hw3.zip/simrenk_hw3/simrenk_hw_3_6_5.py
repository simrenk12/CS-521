"""
Simren Kaur
Class: CS 521 - Summer 2
07/20/2021
Homework Problem 3.14.16

Write a program that reads the file and writes the words to a new text file
so that there are four lines of five single spaced words.

"""
# Read the file
try:
  f = open('test.txt', 'r')
except FileNotFoundError:   # error check
  print('File does not Exist')
  quit()

# Open another file in write mode
f2 = open('new_test.txt', 'w')

# Read the words and splitting them by space
data = f.read().split()

# Make blocks of 5 words and writing to second file
for i in range(0, len(data), 5):
  f2.write(' '.join(data[i:i+5]))
  f2.write('\n')

# Print content in new file
f2 = open('new_test.txt', 'r')
file_contents = f2.read()
print(file_contents)

# Closing both files
f.close()
f2.close()