"""
Simren Kaur
Class: CS 521 - Summer 2
07/20/2021
Homework Problem 3.4.3

Write a program that prompts the user for a sentence and calculates the number
of uppercase letters, lowercase letters, digits, and punctuation.

"""
import string

str = input("Please enter a sentence: ")
upper, lower, number, punct = 0, 0, 0, 0
for i in range(len(str)):
    if str[i].isupper():
        upper += 1
    elif str[i].islower():
        lower += 1
    elif str[i].isdigit():
        number += 1
    elif str[i] in string.punctuation:
        punct += 1

dashes = "--------"

print(f"{'# Upper':^10}", f"{'# Lower':^10}", f"{'# Digit':^10}",
      f"{'# Punct.':^10}")

print(f"{dashes:^10}", f"{dashes:^10}", f"{dashes:^10}", f"{dashes:^10}")
print(f"{upper:^10}", f"{lower:^10}", f"{number:^10}", f"{punct:^10}")



