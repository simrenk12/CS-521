"""
Simren Kaur
Class: CS 521 - Summer 2
07/27/2021
Homework Problem 4.7.3

Write the following python program.
Assign a sentence of at least 15 characters into a string variable.
Write 2 print statements with appropriate descriptions to create output

"""

import collections
import string

STRING = "WAS IT A RAT I SAW"
d = {}
STRING = STRING.replace(" ", "")
for i in STRING:
    if i in d:
        d[i] += 1
    else:
        d[i] = 1

maximum = max(d, key=d.get)
frequent = max(d.values())

print("1. Dictionary of letter counts:", str(d))
print('2. Most frequent letter is : "', str(maximum), '" appears', frequent,
      'times.')



