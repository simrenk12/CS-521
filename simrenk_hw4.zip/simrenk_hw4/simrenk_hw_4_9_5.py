"""
Simren Kaur
Class: CS 521 - Summer 2
07/27/2021
Homework Problem 4.7.5

Using my_dict = {a':15, 'c':18, 'b':20}, write a program to:
a. print all the keys.
b. print all the values.
c. print all the keys and values pairs.
d. print all the keys and values pairs in ascending order of key.
e. print all the keys and values pairs in ascending order of value.

"""

my_dict = {'a':15, 'c':18, 'b':20}

keys = sorted((my_dict.keys()))
values = sorted(my_dict.values())
key_value_pair = (my_dict)
ordered = sorted(my_dict.items())
r_order = sorted(my_dict.items(), reverse=True)

print("Keys:", keys)
print("Values:", str(values)[1:-1])
print("Key value pairs:",str(key_value_pair)[1:-1])
print("Key value pairs ordered by key:",ordered)
print("Key value pairs ordered by value:", str(r_order)[1:-1])
