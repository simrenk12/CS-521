"""
Simren Kaur
Class: CS 521 - Summer 2
07/27/2021
Homework Problem 4.9.4

Start with 2 constant lists. One with first names and another of last names.
First validate that both lists are the same size and if not, exit with an error.
Use zip to create a dictionary with the keys as the last names and the values as
the first names. Print the generated dictionary with an appropriate description.

"""
# create constant list
FIRST_NAMES = ["Jane", "John", "Jack"]

# print constant list
print("First Name:",FIRST_NAMES)

# create constant list
LAST_NAMES = ["Doe", "Deer", "Black"]

# print constant list
print("Last Name:",LAST_NAMES)

# Use zip to create a dictionary
name = zip(FIRST_NAMES, LAST_NAMES)

# Print the generated dictionary
if len(FIRST_NAMES) == len(LAST_NAMES):
    print("Name Dictionary:",dict(name))
else:
    print("Error: List are not the same Length")