"""
Simren Kaur
Class: CS 521 - Summer 2
07/27/2021
Homework Problem 4.7.1

Given a constant list of integers in the range 1 to 10 inclusive
use list comprehension (no explicit loops) to:

- find the sum of the even integers in list L.
- find the sum of the odd integers in list L.
"""
# create the constant list L
L = [1,2,3,4,5,6,7,8,9,10]
# print values in L
print("Evaluating the numbers in:",L)
# use list comprehension to find the evens and odds
even = [num for num in L if num % 2 == 0]
odd = [num for num in L if num % 2 == 1]
# print the sum of the evens and odds
print("Even:", sum(even))
print("Odd:", sum(odd))