"""
Simren Kaur
Class: CS 521 - Summer 2
07/27/2021
Homework Problem 4.7.2

Given a constant list of integers, write Python code to generate a new list
with same number of elements as the original list such that each integer in the
new list is the sum of its nearest neighbors and itself from the original list.
Print both lists with descriptions. Your code should be able to work with an
integer list of any size.

"""
# create the constant list and the new list
LIST = [10,20,30,40,50]
new_list = []

# new list is sum of its nearest neighbors and itself from the original list
new_list.append(LIST[0] + LIST[1])
x = 1
while x < len(LIST) - 1:
    new_list.append(LIST[x - 1] + LIST[x] + LIST[x + 1])
    x += 1
new_list.append(LIST[x - 1] + LIST[x])

# Print both lists with descriptions
print("Input List:",LIST)
print("Result List:",new_list)