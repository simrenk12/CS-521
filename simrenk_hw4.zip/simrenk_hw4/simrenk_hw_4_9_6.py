"""
Simren Kaur
Class: CS 521 - Summer 2
07/27/2021
Homework Problem 4.7.6

Create a program that:
- prompts a user for a number
- validates that a number was entered
- re‐prompts on error
- converts the number to words using a dictionary
- prints out the converted numbers as words

"""
while True:
    # prompts a user for a number
    number = input("Enter a number ")
    # validates that a number was entered
    if number.isprintable() and not number.isalpha():
        # converts the number to words using a dictionary
        dict = {'1': "one", '2': "two", '3': "three", '4': "four", '5': "five",
            '6': "six", '7': "seven", '8': "eight", '9': "nine", '0': "zero",
                '.': "point", '-':"negative"}
        conversion = " ".join(map(lambda x: dict[x], str(number)))
        # prints out the converted numbers as words
        print("As Text: ",  conversion)
        break
    # re‐prompts on error
    else:
        print("you did not enter a number")
